# coding=utf-8
# Insert in a script in Coppelia
# simRemoteApi.start(19999)
# verificacao da conectividade
try:            # tentativa de conexao aceita
    import sim  # ligacao como o modulo python e dll
except:         # tentativa recusada mensagen da sim.py
    print('--------------------------------------------------------------')
    print('"sim.py" could not be imported. This means very probably that')
    print('either "sim.py" or the remoteApi library could not be found.')
    print('Make sure both are in the same folder as this file,')
    print('or appropriately adjust the file "sim.py"')
    print('--------------------------------------------------------------')
    print('')


# load dos packages numerico, graficas e tempo
import numpy as np                #asignacao do pacote como variavel np
import matplotlib.pyplot as plt   #asignacao do pacote como variavel plt
import time                       #asignacao do pacote como variavel np
import random
import math

#definicao funcao leitura sensor parametros de entrada handle,identif sensor (data), identif sensor (angle)
def readSensorData(clientId=-1,range_data_signal_id="hokuyo_range_data",angle_data_signal_id="hokuyo_angle_data"):

 #recuperacao das sinal de entrada do handle baseado em streaming
    returnCodeRanges, string_range_data = sim.simxGetStringSignal(clientId, range_data_signal_id,
                                                                  sim.simx_opmode_streaming)

#recuperacao das sinal de entrada do handle baseado em streaming modo bloqueio
    returnCodeAngles, string_angle_data = sim.simxGetStringSignal(clientId, angle_data_signal_id,
                                                                  sim.simx_opmode_blocking)

    # verificacao da validade dos dados (rango e angulo)
    if returnCodeRanges == 0 and returnCodeAngles == 0:
        # obtencao (unpack data) dos dados a partir dos mensagens
        raw_range_data = sim.simxUnpackFloats(string_range_data)
        raw_angle_data = sim.simxUnpackFloats(string_angle_data)
        # return do dados apos unpack
        return raw_range_data, raw_angle_data

    # return none (nao dados entrando)
    return None

# definicao funcao grafico dados dos laser 
def draw_laser_data(laser_data, max_sensor_range=5):
    fig = plt.figure(figsize=(6, 6), dpi=100)    #grafico matplotlib
    plt.ion()
    ax = fig.add_subplot(111, aspect='equal')    #definicao canvas 

    for i in range(len(laser_data)):            # iteracao de acordo com a quantidade de feixes
        ang, dist = laser_data[i]               # obtencao dados angulo e distancia
        # Quando o feixe não acerta nada, retorna o valor máximo (definido na simulação)
        # Logo, usar um pequeno limiar do máximo para considerar a leitura
        if (max_sensor_range - dist) > 0.1:
            x = dist * np.cos(ang)             #projecao no eixo x
            y = dist * np.sin(ang)             #projecao no eixo y 
            c = 'r'                            #definicao cor= red
            if ang < 0:                        # no caso dos feixes com angulo<0
                c = 'b'                        # definicao cor=black
            ax.plot(x, y, 'o', color=c)        #representacao da linha como "o"

    ax.plot(0, 0, 'k>', markersize=10)         #marcado na grafica
    plt.show(block=False)

    ax.grid()                                  #definicao grid
    ax.set_xlim([-max_sensor_range, max_sensor_range]) #definicao limites eixos graficos x
    ax.set_ylim([-max_sensor_range, max_sensor_range]) #definicao limites eixos graficos y
    plt.show()  # apresentacao grafico
    #time.sleep(200)  # aguarda algum tempo
    plt.close()

print('Programa iniciado')                                        # mensagem console python 
sim.simxFinish(-1)                                                # fechado das conexoes 
clientID = sim.simxStart('127.0.0.1', 19999, True, True, 5000, 5) #thread comunicacao com server  (ip Address e porto)

if clientID != -1:                                                # verificacao comunicao 
    
    res, objs = sim.simxGetObjects(clientID, sim.sim_handle_all, sim.simx_opmode_blocking) # obtencao de dados modo blocking
    if res == sim.simx_return_ok:                                 # obtencao exitosa
        print('Number of objects in the scene: ', (objs))         # impresao quantidade de objetos na escena
    else:                                                         # comandos no caso nao exitoso
        print('Remote API function call returned with errlenor code: ', res) #obtencao do erro na comunicacao

    # Iniciando a simulação
    sim.simxStartSimulation(clientID, sim.simx_opmode_oneshot_wait) # Deve usar a porta do 'continuous remote API server services' (remoteApiConnections.txt)
    print('Connected to remote API server')                         # conexao no server
    sim.simxAddStatusbarMessage(clientID, 'Iniciando...', sim.simx_opmode_oneshot_wait) #apertura da leitura
    time.sleep(0.02)                                                                    #aguarda algum tempo
    # Handle para modelo do Robô
    robotname = 'Pioneer_p3dx'                                                         # nome do modelo
    erro, robotHandle = sim.simxGetObjectHandle(clientID, robotname, sim.simx_opmode_oneshot_wait) #handle/conexao com o robo
    # Handle para as juntas das RODAS
    returnCode, l_wheel = sim.simxGetObjectHandle(clientID, robotname + '_leftMotor', sim.simx_opmode_oneshot_wait) #handle/conexao com as rodas
    returnCode, r_wheel = sim.simxGetObjectHandle(clientID, robotname + '_rightMotor', sim.simx_opmode_oneshot_wait)
    # Criar stream de dados
    [returnCode, positionrobot] = sim.simxGetObjectPosition(clientID, robotHandle, -1, sim.simx_opmode_streaming)       #obt posic
    [returnCode, orientationrobot] = sim.simxGetObjectOrientation(clientID, robotHandle, -1, sim.simx_opmode_streaming) #obt orientac
    time.sleep(0.05)                                                                   #aguarda algum tempo
    # Handle para os dados do LASER
    laser_range_data = "hokuyo_range_data"
    laser_angle_data = "hokuyo_angle_data"
    # Geralmente a primeira leitura é inválida (atenção ao Operation Mode)
    # Em loop até garantir que as leituras serão válidas
    returnCode = 1
    while returnCode != 0:
        returnCode, range_data = sim.simxGetStringSignal(clientID, laser_range_data, sim.simx_opmode_streaming + 10) #primeira leitura da informacao lasers

    # Reiteracao das leituras
    raw_range_data, raw_angle_data = readSensorData(clientID, laser_range_data, laser_angle_data)
    laser_data = np.array([raw_angle_data, raw_range_data]).T                                  # conversao das leituras num array
    print('laser data',laser_data)                                                                          #impresao dados lasers
    returnCode, pos = sim.simxGetObjectPosition(clientID, robotHandle, -1, sim.simx_opmode_oneshot_wait)
    print('Pos: ', pos)                                                                        #impresao posicao
##########################################################################################################
    # Dados do Pioneer
    L = 0.381  # Metros
    r = 0.0975  # Metros
    t = 0
########################################################################################################    
    # Lembrar de habilitar o 'Real-time mode'
    startTime = time.time()
    lastTime = startTime
    dt = 0
    i = 0
    mxLyL=0
    while t < 240:
        now = time.time()
        dt = now - lastTime


        # Fazendo leitura do laser
        raw_range_data, raw_angle_data = readSensorData(clientID, laser_range_data, laser_angle_data)
        laser_data = np.array([raw_angle_data, raw_range_data]).T                               # conversao das leituras num array
###############################################################################################################
        elemento = 'ResizableFloor_5_25_element'                                                         # nome do modelo
        erro, elementHandle = sim.simxGetObjectHandle(clientID, elemento, sim.simx_opmode_oneshot_wait) #handle/conexao com o robo
        returnCode, posesq = sim.simxGetObjectPosition(clientID, elementHandle, -1, sim.simx_opmode_oneshot_wait)
        #print('centro elemento',posesq)
        bordasupder=(posesq[1]-2.5)
        #print('centroide sup-der  ',posesq," bordas",bordasupder)
        
        elemento = 'ResizableFloor_5_25_element7'                                                         # nome do modelo
        erro, elementHandle = sim.simxGetObjectHandle(clientID, elemento, sim.simx_opmode_oneshot_wait) #handle/conexao com o robo
        returnCode, posesq = sim.simxGetObjectPosition(clientID, elementHandle, -1, sim.simx_opmode_oneshot_wait)
        #print('centro elemento',posesq)
        bordainfesq=(posesq[1]+2.5)
        #print('centroide sup-der  ',posesq," bordas",bordainfesq)
        RES=0.02
        altgrid=bordainfesq/RES
        larggrid=bordainfesq/RES
        print('grid',altgrid)

        #,poseseq[2]+sim.getObjectFloatParam(elementHandle,16))
        #local orig_floor1 = sim.getObjectPosition(floor1,-1)
        #   floor1 = sim.getObjectHandle('ResizableFloor_5_25_element')
        #   floor2 = sim.getObjectHandle('ResizableFloor_5_25_element1')
        #   floor3 = sim.getObjectHandle('ResizableFloor_5_25_element5')
        #   floor4 = sim.getObjectHandle('ResizableFloor_5_25_element7')        

#MAPEAMENTO - INICIO
        #Para cada feixe de laser
            #INVERSE SENSOR MODEL
        RANGE_MAX = 5
        RANGE_LIMIT = 0.3
        PRIORI = 0.5
            
        if raw_angle_data[i] < RANGE_MAX * RANGE_LIMIT:
            taxaOC = 0.9
        else:
              taxaOC = 0.48
            

            # Calcular a posição xL, yL de onde o laser bateu
        #print(,positionrobot[2])   
        theta=0
        posX=positionrobot[1]
        posY=positionrobot[2]
        xL = math.cos(raw_angle_data[i] + theta) * raw_angle_data[i] / RES + (posX); 
        #// + altgrid / 2;
        yL = math.sin(raw_angle_data[i] + theta) * raw_angle_data[i] / RES + (posY);
            #posX e posY são as coordenadas do robô na GRID

            # Calcular todos as células de acordo com o algoritmo de Bresenham
        rows=int(altgrid)
        cols=int(larggrid)
        line_bresenham = np.zeros((rows, cols), dtype=np.uint8)
        ca=0
        #rr, cc = math.line(yL+RES, xL+RES, yL, xL)  # r0, c0, r1, c1
        m=(yL+RES-yL)/(xL+RES-xL)
        cc=int(m*xL)+ca
        rr=int(xL)
        line_bresenham[rr, cc] = 1

            #ATUALIZAR A GRID
            #Para cada célula da matriz por onde o feixe passa
                #Atualizar a GRID

        apriori=random.random()
        print('prob previa ',apriori)
        print(1 - pow(1 + ((taxaOC / (1 - taxaOC)) * ((1 - PRIORI) / PRIORI) * (apriori / (1 - apriori))), -1) )
        mxLyL=1 - pow(1 + ((taxaOC / (1 - taxaOC)) * ((1 - PRIORI) / PRIORI) * (apriori / (1 - apriori))), -1)
        print('prob nova ',mxLyL)
        #P(MxLyL) = 1 - math.pow((1 + (taxaOC / (1 - taxaOC)) ))
        #print(1 - math.pow((1 + (taxaOC / (1 - taxaOC)) )   ))
                                 #* ((1 - PRIORI) / PRIORI) * (m[xL,yL] / ((1 - m[xL,yL])), -1));

                #Atualizar xL, yL de acordo com o algoritmo de Bresenham
        #MAPEAMENTO - FIM
#########################################################################################################
        # Calculo Velocidades linear e angular
        v = 0                                                           
        w = np.deg2rad(0)
       # definicao da longitud do feixe e decisao dos movimentos
        frente = int(len(laser_data) / 2)
        lado_direito = int(len(laser_data) * 1 / 4)
        lado_esquerdo = int(len(laser_data) * 3 / 4)

        if laser_data[frente, 1] < 1:
            v = 0.1
            w = np.deg2rad(-15)
        elif laser_data[lado_direito, 1] < 1:
            v = 0.1
            w = np.deg2rad(15)
        elif laser_data[lado_esquerdo, 1] < 1:
            v = 0.1
            w = np.deg2rad(-15)
        else:
            v = 0.5
            w = 0
        # mensagen para impresao na console coppelia
        sim.simxAddStatusbarMessage(clientID, str(i) + '- Frente: ' + str(laser_data[frente, 1]) + ' - Direito: ' + str(
            laser_data[lado_direito, 1]) + ' - Esquerdo: ' + str(laser_data[lado_esquerdo, 1]),
                                    sim.simx_opmode_oneshot_wait)
        # Isso é o modelo cinemático
        wl = v / r - (w * L) / (2 * r)
        wr = v / r + (w * L) / (2 * r)
        sim.simxSetJointTargetVelocity(clientID, l_wheel, wl, sim.simx_opmode_streaming + 5)   # envio velocidad coppelia
        sim.simxSetJointTargetVelocity(clientID, r_wheel, wr, sim.simx_opmode_streaming + 5)
        #print('iteracao (240 max)',t)
        t = t + dt                                                                            # incremento apos iteracao
     #   draw_laser_data(laser_data, 5)                                                       #apresentacao dados lasers
        i = i + 1                                                                             # incremento contador
        lastTime = now
        

    # Parando o robô
    sim.simxSetJointTargetVelocity(clientID, r_wheel, 0, sim.simx_opmode_oneshot_wait)   #velocidad nula (parada) roda dereita
    sim.simxSetJointTargetVelocity(clientID, l_wheel, 0, sim.simx_opmode_oneshot_wait)   #velocidad nula (parada) roda dereita
    print('graficofinal laser')
    draw_laser_data(laser_data, 5)                                                       #apresentacao dados lasers
    sim.simxStopSimulation(clientID, sim.simx_opmode_blocking)                           # Parando a simulação

    sim.simxFinish(clientID)                                                            # finalizacao comunicacao 

else:
    print('Erro na comunicacao com server remote API server')
print('Program ended')                                                                  # fim do programa
